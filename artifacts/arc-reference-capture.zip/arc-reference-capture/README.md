# 在本机采集 Arc 参考界面

需要 macOS 14 或更新版本、Xcode Command Line Tools，以及已经打开并登录的原版 Arc。

解压后进入本目录，编译并列出 Arc 窗口：

```sh
xcrun swiftc -parse-as-library -O -target "$(uname -m)-apple-macosx14.0" capture-arc-reference.swift -o /tmp/capture-arc-reference
/tmp/capture-arc-reference --list
```

在 Arc 中手动打开需要对照的界面，把下面 PID 和窗口 ID 换成列表里的实际值：

```sh
/tmp/capture-arc-reference --pid 12345 --window-id 6789 --output "$HOME/Desktop/arc-reference-sidebar" --label "Sidebar expanded"
```

每次使用一个不存在的新输出目录。成功后得到 window.png 和 metadata.json。可分别采集展开/收起侧栏、命令栏、分屏、Library、设置等状态；独立弹窗需要选择其自己的窗口 ID。

工具不会登录、启动、点击、修改或关闭 Arc，也不读取浏览器数据库、Cookie 或账号凭据。它仅验证原版签名、记录版本与窗口信息、保存选定窗口的真实像素。截图服务超过 30 秒未返回时退出 124，不写出替代图像。

如果系统没有授予屏幕录制权限，工具会报错。权限需由你在本机系统设置中处理，工具不会自行修改。

云端验证覆盖了真实欢迎页截图、参数/身份/输出保护、像素检查和超时机制。登录后的浏览器状态和 Intel 机器仍需实际采集确认。更多说明见 DETAILS.md。
